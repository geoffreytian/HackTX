
_BATCH_ACCOUNT_NAME = 'news'  # Your batch account name
_BATCH_ACCOUNT_KEY = '5uJxr4I4u1Z02YteCnWaWHoOxr6GxMeQkFjt1s/K4PlAP1y6xu0IpJGg8zTOZZVlZckK/DuxophuHfqFAeLppA=='  # Your batch account key
_BATCH_ACCOUNT_URL = 'https://news.eastus.batch.azure.com'  # Your batch account URL
_STORAGE_ACCOUNT_NAME = 'hacktx'  # Your storage account name
_STORAGE_ACCOUNT_KEY = '1hmCn9TjWFGW2Loerw502i8AOjK59Qx7pXxFcDHCasKZHQtypcWY8xhHliW05DrpowksXeDSEMQx5mfEiDkGPw=='  # Your storage account key
_POOL_ID = 'NewsPool'  # Your Pool ID
_POOL_NODE_COUNT = 2  # Pool node count
_POOL_VM_SIZE = 'STANDARD_A1_v2'  # VM Type/Size
_JOB_ID = 'NewsPoolJob'  # Job ID
# _STANDARD_OUT_FILE_NAME = 'stdout.txt'  # Standard Output file